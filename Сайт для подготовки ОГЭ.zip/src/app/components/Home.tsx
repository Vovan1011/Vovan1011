import { Link } from "react-router";
import { Button } from "./ui/button";
import { GraduationCap } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

export function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-blue-50 to-white dark:from-gray-900 dark:to-gray-800">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      {/* Hero Section */}
      <div className="container mx-auto px-4 py-16">
        <div className="text-center mb-16">
          <div className="flex justify-center mb-6">
            <div className="bg-blue-600 text-white p-4 rounded-full">
              <GraduationCap size={48} />
            </div>
          </div>
          <h1 className="text-5xl mb-4">Подготовка к ОГЭ по физике 2026</h1>
          <p className="text-xl text-gray-600 dark:text-gray-300 max-w-2xl mx-auto">
            Комплексная платформа для успешной подготовки к основному государственному экзамену по физике
          </p>
          <div className="mt-8">
            <Link to="/subjects/3">
              <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-lg px-8 py-6">
                Начать подготовку
              </Button>
            </Link>
          </div>
        </div>

        {/* About Section */}
        <div className="mt-20 max-w-4xl mx-auto">
          <h2 className="text-4xl text-center mb-8">О платформе</h2>
          <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-10">
            <p className="text-gray-700 dark:text-gray-300 mb-4 text-lg">
              Наша платформа создана для учащихся 9 классов, готовящихся к сдаче ОГЭ по физике. 
              Мы предоставляем структурированные материалы по всем основным темам экзамена.
            </p>
            <p className="text-gray-700 dark:text-gray-300 mb-4 text-lg">
              Каждая тема содержит подробную теорию и практические задания, 
              которые помогут закрепить полученные знания.
            </p>
            <p className="text-gray-700 dark:text-gray-300 text-lg">
              Начните свою подготовку прямо сейчас!
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}