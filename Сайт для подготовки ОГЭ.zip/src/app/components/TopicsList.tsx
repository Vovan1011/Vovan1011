import { Link, useParams, useNavigate } from "react-router";
import { Card } from "./ui/card";
import { Button } from "./ui/button";
import { subjects } from "../data/subjects";
import { ChevronRight, ArrowLeft } from "lucide-react";
import { ThemeToggle } from "./ThemeToggle";

export function TopicsList() {
  const { subjectId } = useParams();
  const navigate = useNavigate();
  
  const subject = subjects.find(s => s.id === Number(subjectId));

  if (!subject) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl mb-4">Предмет не найден</h2>
          <Button onClick={() => navigate("/")}>Вернуться на главную</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      {/* Theme Toggle */}
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      <div className="bg-blue-600 text-white py-12">
        <div className="container mx-auto px-4">
          <Button
            variant="ghost"
            onClick={() => navigate("/")}
            className="text-white hover:bg-blue-700 mb-4"
          >
            <ArrowLeft className="mr-2" size={20} />
            Назад на главную
          </Button>
          <div className="flex items-center gap-3 mb-2">
            <span className="text-5xl">{subject.icon}</span>
            <h1 className="text-4xl">{subject.name}</h1>
          </div>
          <p className="text-blue-100 dark:text-blue-200">{subject.description}</p>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12">
        <h2 className="text-2xl mb-6">Темы для изучения</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {subject.topics.map((topic) => (
            <Link key={topic.id} to={`/subjects/${subject.id}/topics/${topic.id}`}>
              <Card className="p-5 hover:shadow-lg transition-all hover:-translate-y-1 cursor-pointer">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <h3 className="text-xl mb-1">{topic.title}</h3>
                    <p className="text-sm text-gray-500 dark:text-gray-400">
                      Задания с ФИПИ · PDF с теорией
                    </p>
                  </div>
                  <ChevronRight className="text-gray-400 flex-shrink-0 ml-2" />
                </div>
              </Card>
            </Link>
          ))}
        </div>
      </div>
    </div>
  );
}