import { useParams, useNavigate } from "react-router";
import { Button } from "./ui/button";
import { Card } from "./ui/card";
import { subjects, Task } from "../data/subjects";
import { ArrowLeft, BookOpen, CheckCircle, ExternalLink, Loader2, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { ThemeToggle } from "./ThemeToggle";
import { getPhysicsOgeQuestions, FipiTask } from "../services/fipiService";

function PdfViewer({ url, title }: { url: string; title: string }) {
  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center justify-between">
        <span className="text-sm text-gray-500 dark:text-gray-400">PDF-файл с теорией</span>
        <a
          href={url}
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-1 text-sm text-blue-600 hover:underline"
        >
          Открыть в новой вкладке
          <ExternalLink size={14} />
        </a>
      </div>
      <iframe
        src={url}
        title={title}
        className="w-full rounded border border-gray-200 dark:border-gray-700"
        style={{ height: "600px" }}
      />
    </div>
  );
}

function QuestionCard({
  task,
  index,
  showAnswer,
  onToggle,
}: {
  task: FipiTask | Task;
  index: number;
  showAnswer: boolean;
  onToggle: () => void;
}) {
  const hasProblemHtml = "problemHtml" in task && task.problemHtml;
  const hasImages = "imageUrls" in task && task.imageUrls && task.imageUrls.length > 0;

  return (
    <Card className="p-6">
      <div className="mb-3">
        <div className="flex items-center gap-2 flex-wrap mb-3">
          <span className="inline-block bg-blue-100 text-blue-700 px-3 py-1 rounded-full text-sm">
            Задание {index + 1}
          </span>
          {"codifier" in task && task.codifier?.map((c, i) => (
            <span key={i} className="text-xs bg-gray-100 dark:bg-gray-700 px-2 py-0.5 rounded text-gray-600 dark:text-gray-300">
              {c}
            </span>
          ))}
          {"answerType" in task && task.answerType && (
            <span className="text-xs bg-purple-100 dark:bg-purple-900/40 text-purple-700 dark:text-purple-300 px-2 py-0.5 rounded">
              {task.answerType}
            </span>
          )}
        </div>

        {hasProblemHtml ? (
          <div
            className="text-base leading-relaxed"
            dangerouslySetInnerHTML={{ __html: (task as FipiTask).problemHtml! }}
          />
        ) : (
          <p className="text-lg whitespace-pre-line">{task.question}</p>
        )}

        {hasImages && (
          <div className="flex flex-wrap gap-2 mt-3">
            {(task as FipiTask).imageUrls!.map((url, i) => (
              <img key={i} src={url} alt={`Иллюстрация ${i + 1}`} className="max-h-48 rounded border" />
            ))}
          </div>
        )}
      </div>

      <div className="mt-4">
        <Button variant={showAnswer ? "default" : "outline"} size="sm" onClick={onToggle}>
          {showAnswer ? "Скрыть ответ" : "Показать ответ"}
        </Button>
        {showAnswer && (
          <div className="mt-4 p-4 bg-green-50 dark:bg-green-900/20 border-l-4 border-green-500 rounded">
            <p className="text-green-800 dark:text-green-300">
              <strong>Ответ:</strong> {task.answer}
            </p>
          </div>
        )}
      </div>
    </Card>
  );
}

export function TopicDetail() {
  const { subjectId, topicId } = useParams();
  const navigate = useNavigate();
  const [showAnswers, setShowAnswers] = useState<{ [key: number]: boolean }>({});
  const [tasks, setTasks] = useState<(FipiTask | Task)[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");

  const subject = subjects.find(s => s.id === Number(subjectId));
  const topic = subject?.topics.find(t => t.id === Number(topicId));
  const isPhysics = subject?.id === 3;

  useEffect(() => {
    if (!topic) return;

    if (!isPhysics) {
      setTasks(topic.tasks);
      return;
    }

    setLoading(true);
    setError("");
    getPhysicsOgeQuestions(topic.codifierKeyword ?? topic.title)
      .then(setTasks)
      .catch(err => {
        setError(err.message);
        setTasks(topic.tasks);
      })
      .finally(() => setLoading(false));
  }, [subjectId, topicId]);

  const toggleAnswer = (taskId: number) =>
    setShowAnswers(prev => ({ ...prev, [taskId]: !prev[taskId] }));

  if (!subject || !topic) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl mb-4">Тема не найдена</h2>
          <Button onClick={() => navigate("/subjects")}>Вернуться к предметам</Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900">
      <div className="fixed top-4 right-4 z-50">
        <ThemeToggle />
      </div>

      <div className="bg-blue-600 text-white py-8">
        <div className="container mx-auto px-4">
          <Button
            variant="ghost"
            onClick={() => navigate(`/subjects/${subject.id}`)}
            className="text-white hover:bg-blue-700 mb-4"
          >
            <ArrowLeft className="mr-2" size={20} />
            Назад к темам
          </Button>
          <div className="flex items-center gap-2 text-sm text-blue-100 mb-2">
            <span>{subject.name}</span>
            <span>/</span>
            <span>{topic.title}</span>
          </div>
          <h1 className="text-4xl">{topic.title}</h1>
        </div>
      </div>

      <div className="container mx-auto px-4 py-12 max-w-4xl">
        <Card className="p-8 mb-8">
          <div className="flex items-center gap-2 mb-4">
            <BookOpen className="text-blue-600" size={24} />
            <h2 className="text-2xl">Теория</h2>
          </div>
          <PdfViewer url={topic.pdfUrl} title={topic.title} />
        </Card>

        <div>
          <h2 className="text-2xl mb-4 flex items-center gap-2">
            <CheckCircle className="text-green-600" size={24} />
            Практические задания
            {isPhysics && !loading && tasks.length > 0 && (
              <span className="text-sm text-gray-500 font-normal ml-1">
                — {tasks.length} заданий с ФИПИ
              </span>
            )}
          </h2>

          {loading && (
            <Card className="p-6 mb-4 flex items-center gap-3 text-blue-600">
              <Loader2 size={20} className="animate-spin" />
              <p className="font-medium">Загрузка заданий с ФИПИ...</p>
            </Card>
          )}

          {error && (
            <Card className="p-4 mb-4 border-amber-200 bg-amber-50 dark:bg-amber-900/20 flex items-start gap-3">
              <AlertCircle size={18} className="text-amber-600 mt-0.5 shrink-0" />
              <p className="text-sm text-amber-800 dark:text-amber-300">
                {error} — показаны демо-задания.
              </p>
            </Card>
          )}

          <div className="space-y-4">
            {tasks.map((task, index) => (
              <QuestionCard
                key={task.id}
                task={task}
                index={index}
                showAnswer={!!showAnswers[task.id]}
                onToggle={() => toggleAnswer(task.id)}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
