// URL задеплоенного questions-parser.
// Задайте в .env файле: VITE_FIPI_API_URL=https://your-parser.railway.app
// Если переменная не задана — используются вопросы из fipiQuestions.json.
//
// Чтобы обновить fipiQuestions.json всеми вопросами с ФИПИ:
//   1. Запустите questions-parser: python manage.py runserver
//   2. python scripts/fetch-fipi-questions.py
const FIPI_API_URL = import.meta.env.VITE_FIPI_API_URL as string | undefined;

import allQuestions from "../data/fipiQuestions.json";

export interface FipiTask {
  id: number;
  question: string;
  answer: string;
  problemHtml?: string;
  imageUrls?: string[];
  codifier?: string[];
  answerType?: string;
}

interface RawQuestion {
  id: string;
  guid: string;
  hint: string;
  codifier: string[];
  question: string;
  problem: string;
  img: string[];
  img_urls: string[];
  answer_type: string;
  answer: string;
}

function mapQuestions(raw: RawQuestion[]): FipiTask[] {
  return raw.map((q, index) => ({
    id: index + 1,
    question: q.question?.trim() || q.hint?.trim() || `Задание ${index + 1}`,
    answer: q.answer?.trim() || "Ответ не указан",
    problemHtml: q.problem,
    imageUrls: q.img_urls?.filter(Boolean),
    codifier: q.codifier,
    answerType: q.answer_type,
  }));
}

// Возвращает все вопросы, опционально отфильтрованные по кодификатору темы.
// codifierKeyword — подстрока из кодификатора, например "Испарение".
// Если не передан — возвращает все вопросы.
export async function getPhysicsOgeQuestions(codifierKeyword?: string): Promise<FipiTask[]> {
  let raw: RawQuestion[];

  if (FIPI_API_URL) {
    const response = await fetch(`${FIPI_API_URL}/parse/?bank=phy_oge`);
    if (!response.ok) throw new Error(`Сервер вернул ошибку ${response.status}`);
    raw = await response.json();
  } else {
    raw = allQuestions as RawQuestion[];
  }

  if (codifierKeyword) {
    const keyword = codifierKeyword.toLowerCase();
    raw = raw.filter(q =>
      q.codifier?.some(c => c.toLowerCase().includes(keyword))
    );
  }

  return mapQuestions(raw);
}
