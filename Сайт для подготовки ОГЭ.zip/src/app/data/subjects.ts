import pdf3 from "../../imports/___.pdf?url";
import pdf4 from "../../imports/____.pdf?url";
import pdf5 from "../../imports/_____.pdf?url";
import pdf6 from "../../imports/______.pdf?url";
import pdf7 from "../../imports/_______.pdf?url";
import pdf8 from "../../imports/________.pdf?url";
import pdf9 from "../../imports/_________.pdf?url";

export interface Task {
  id: number;
  question: string;
  answer: string;
}

export interface Topic {
  id: number;
  title: string;
  pdfUrl: string;
  codifierKeyword?: string;
  tasks: Task[];
}

export interface Subject {
  id: number;
  name: string;
  description: string;
  icon: string;
  topics: Topic[];
}

export const subjects: Subject[] = [
  {
    id: 3,
    name: "Физика",
    description: "Подготовка к ОГЭ по физике",
    icon: "⚡",
    topics: [
      {
        id: 1,
        title: "Законы сохранения. Работа и мощность",
        pdfUrl: pdf3,
        codifierKeyword: "Законы сохранения",
        tasks: [],
      },
      {
        id: 2,
        title: "Статика и гидростатика",
        pdfUrl: pdf4,
        codifierKeyword: "Статика",
        tasks: [],
      },
      {
        id: 3,
        title: "Тепловые явления",
        pdfUrl: pdf5,
        codifierKeyword: "Тепловые явления",
        tasks: [
          { id: 1, question: "Чему равна масса спирта, если в процессе его превращения из газообразного состояния в жидкое при температуре кипения выделилось количество теплоты 90 000 Дж?", answer: "0,1 кг" },
          { id: 2, question: "Какое количество теплоты необходимо затратить, чтобы перевести в газообразное состояние 0,1 кг спирта при температуре кипения?", answer: "85 кДж" },
        ],
      },
      {
        id: 4,
        title: "Электростатика",
        pdfUrl: pdf6,
        codifierKeyword: "Электростатика",
        tasks: [],
      },
      {
        id: 5,
        title: "Постоянный ток",
        pdfUrl: pdf7,
        codifierKeyword: "Постоянный ток",
        tasks: [],
      },
      {
        id: 6,
        title: "Колебания и волны",
        pdfUrl: pdf8,
        codifierKeyword: "Колебания",
        tasks: [],
      },
      {
        id: 7,
        title: "Оптика",
        pdfUrl: pdf9,
        codifierKeyword: "Оптика",
        tasks: [],
      },
    ],
  },
];
