import { createBrowserRouter } from "react-router";
import { Home } from "./components/Home";
import { TopicsList } from "./components/TopicsList";
import { TopicDetail } from "./components/TopicDetail";

export const router = createBrowserRouter([
  {
    path: "/",
    Component: Home,
  },
  {
    path: "/subjects/:subjectId",
    Component: TopicsList,
  },
  {
    path: "/subjects/:subjectId/topics/:topicId",
    Component: TopicDetail,
  },
]);
