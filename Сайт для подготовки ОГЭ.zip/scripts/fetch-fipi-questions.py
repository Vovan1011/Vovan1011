"""
Скрипт для получения всех вопросов ОГЭ по физике с ФИПИ.

Требования:
  1. Запустить questions-parser: python manage.py runserver
     (https://github.com/skies21/questions-parser)
  2. Запустить этот скрипт: python scripts/fetch-fipi-questions.py

Скрипт вызывает questions-parser, который парсит oge.fipi.ru,
и сохраняет все вопросы в src/app/data/fipiQuestions.json.
"""

import json
import sys
import urllib.request
import urllib.error

PARSER_URL = "http://localhost:8000/parse/?bank=phy_oge"
OUTPUT_FILE = "src/app/data/fipiQuestions.json"

print("Подключение к questions-parser...")
print(f"URL: {PARSER_URL}")
print("(Это может занять несколько минут — парсер перебирает все страницы ФИПИ)\n")

try:
    with urllib.request.urlopen(PARSER_URL, timeout=300) as response:
        raw = response.read().decode("utf-8")
        questions = json.loads(raw)
except urllib.error.URLError as e:
    print(f"Ошибка подключения: {e}")
    print("\nУбедитесь что questions-parser запущен:")
    print("  cd questions-parser")
    print("  python manage.py runserver")
    sys.exit(1)
except json.JSONDecodeError as e:
    print(f"Ошибка разбора ответа: {e}")
    sys.exit(1)

print(f"Получено вопросов: {len(questions)}")

# Показываем кодификаторы (темы) которые встретились
all_codifiers = set()
for q in questions:
    for c in q.get("codifier", []):
        all_codifiers.add(c)

print(f"\nТемы ({len(all_codifiers)} шт.):")
for c in sorted(all_codifiers):
    print(f"  • {c}")

with open(OUTPUT_FILE, "w", encoding="utf-8") as f:
    json.dump(questions, f, ensure_ascii=False, indent=2)

print(f"\nСохранено в {OUTPUT_FILE}")
print("Перезапустите сайт чтобы увидеть все вопросы.")
