import { Hono } from "npm:hono";
import { cors } from "npm:hono/cors";
import { logger } from "npm:hono/logger";
import * as kv from "./kv_store.tsx";
import { createClient } from "npm:@supabase/supabase-js@2";

const app = new Hono();

// Enable logger
app.use('*', logger(console.log));

// Enable CORS for all routes and methods
app.use(
  "/*",
  cors({
    origin: "*",
    allowHeaders: ["Content-Type", "Authorization"],
    allowMethods: ["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    exposeHeaders: ["Content-Length"],
    maxAge: 600,
  }),
);

// Health check endpoint
app.get("/make-server-b117e8de/health", (c) => {
  return c.json({ status: "ok" });
});

// User Signup
app.post("/make-server-b117e8de/signup", async (c) => {
  try {
    const { email, password, name } = await c.req.json();
    
    if (!email || !password || !name) {
      return c.json({ error: "Email, password, and name are required" }, 400);
    }

    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!,
    );

    const { data, error } = await supabase.auth.admin.createUser({
      email,
      password,
      user_metadata: { name },
      // Automatically confirm the user's email since an email server hasn't been configured.
      email_confirm: true
    });

    if (error) {
      console.log('Signup error:', error);
      return c.json({ error: error.message }, 400);
    }

    return c.json({ user: data.user });
  } catch (error) {
    console.log('Signup exception:', error);
    return c.json({ error: 'Failed to create user' }, 500);
  }
});

// Get Forum Questions
app.get("/make-server-b117e8de/forum/questions", async (c) => {
  try {
    const questions = await kv.getByPrefix("question:");
    
    // Sort by creation date (newest first)
    questions.sort((a, b) => b.value.createdAt - a.value.createdAt);
    
    return c.json({ questions: questions.map(q => q.value) });
  } catch (error) {
    console.log('Get questions error:', error);
    return c.json({ error: 'Failed to fetch questions' }, 500);
  }
});

// Get Single Question with Answers
app.get("/make-server-b117e8de/forum/questions/:id", async (c) => {
  try {
    const id = c.req.param('id');
    const question = await kv.get(`question:${id}`);
    
    if (!question) {
      return c.json({ error: 'Question not found' }, 404);
    }

    const answers = await kv.getByPrefix(`answer:${id}:`);
    answers.sort((a, b) => a.value.createdAt - b.value.createdAt);

    return c.json({ 
      question,
      answers: answers.map(a => a.value)
    });
  } catch (error) {
    console.log('Get question error:', error);
    return c.json({ error: 'Failed to fetch question' }, 500);
  }
});

// Create Forum Question (requires auth)
app.post("/make-server-b117e8de/forum/questions", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const { title, content, subject } = await c.req.json();
    
    if (!title || !content) {
      return c.json({ error: 'Title and content are required' }, 400);
    }

    const questionId = crypto.randomUUID();
    const question = {
      id: questionId,
      title,
      content,
      subject: subject || 'Общее',
      authorId: user.id,
      authorName: user.user_metadata.name || user.email,
      createdAt: Date.now(),
      answerCount: 0
    };

    await kv.set(`question:${questionId}`, question);

    return c.json({ question });
  } catch (error) {
    console.log('Create question error:', error);
    return c.json({ error: 'Failed to create question' }, 500);
  }
});

// Create Answer (requires auth)
app.post("/make-server-b117e8de/forum/questions/:id/answers", async (c) => {
  try {
    const accessToken = c.req.header('Authorization')?.split(' ')[1];
    
    const supabase = createClient(
      Deno.env.get('SUPABASE_URL')!,
      Deno.env.get('SUPABASE_ANON_KEY')!,
    );

    const { data: { user }, error: authError } = await supabase.auth.getUser(accessToken);
    
    if (!user || authError) {
      return c.json({ error: 'Unauthorized' }, 401);
    }

    const questionId = c.req.param('id');
    const { content } = await c.req.json();
    
    if (!content) {
      return c.json({ error: 'Content is required' }, 400);
    }

    const question = await kv.get(`question:${questionId}`);
    if (!question) {
      return c.json({ error: 'Question not found' }, 404);
    }

    const answerId = crypto.randomUUID();
    const answer = {
      id: answerId,
      questionId,
      content,
      authorId: user.id,
      authorName: user.user_metadata.name || user.email,
      createdAt: Date.now()
    };

    await kv.set(`answer:${questionId}:${answerId}`, answer);

    // Update answer count
    question.answerCount = (question.answerCount || 0) + 1;
    await kv.set(`question:${questionId}`, question);

    return c.json({ answer });
  } catch (error) {
    console.log('Create answer error:', error);
    return c.json({ error: 'Failed to create answer' }, 500);
  }
});

Deno.serve(app.fetch);