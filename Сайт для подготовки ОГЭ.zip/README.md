
  # Сайт для подготовки ОГЭ

  This is a code bundle for Сайт для подготовки ОГЭ. The original project is available at https://www.figma.com/design/hHaw0qZwkUNJXZLN4uqiQr/%D0%A1%D0%B0%D0%B9%D1%82-%D0%B4%D0%BB%D1%8F-%D0%BF%D0%BE%D0%B4%D0%B3%D0%BE%D1%82%D0%BE%D0%B2%D0%BA%D0%B8-%D0%9E%D0%93%D0%AD.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  